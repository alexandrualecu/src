/* tslint:disable:no-unused-variable */

import { StripHtmlPipe } from './stripHtml.pipe';

describe('Pipe: StripHtmle', () => {
  it('create an instance', () => {
    let pipe: StripHtmlPipe = new StripHtmlPipe();
    expect(pipe).toBeTruthy();
  });
});
