export const environment: any = {
  production: true,
  useHash: false,
};
